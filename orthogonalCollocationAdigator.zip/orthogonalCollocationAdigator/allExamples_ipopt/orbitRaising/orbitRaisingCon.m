function constraints = orbitRaisingCon(Z)
% computes the constraints

output      = orbitRaisingFun(Z);
constraints = output;

end

