function jac = robotArmJac(Z)
% computes the jacobian

[jac,~] = robotArmFun_Jac(Z);

end

