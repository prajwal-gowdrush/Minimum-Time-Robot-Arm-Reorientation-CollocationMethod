function grd = robotArmGrd(Z)
% computes the gradient

output = robotArmObj_Jac(Z);
grd    = output;

end

