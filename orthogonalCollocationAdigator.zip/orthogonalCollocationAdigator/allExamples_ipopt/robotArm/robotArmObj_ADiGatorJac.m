% This code was generated using ADiGator version 1.4
% �2010-2014 Matthew J. Weinstein and Anil V. Rao
% ADiGator may be obtained at https://sourceforge.net/projects/adigator/ 
% Contact: mweinstein@ufl.edu
% Bugs/suggestions may be reported to the sourceforge forums
%                    DISCLAIMER
% ADiGator is a general-purpose software distributed under the GNU General
% Public License version 3.0. While the software is distributed with the
% hope that it will be useful, both the software and generated code are
% provided 'AS IS' with NO WARRANTIES OF ANY KIND and no merchantability
% or fitness for any purpose or application.

function obj = robotArmObj_ADiGatorJac(z)
global ADiGator_robotArmObj_ADiGatorJac
if isempty(ADiGator_robotArmObj_ADiGatorJac); ADiGator_LoadData(); end
Gator1Data = ADiGator_robotArmObj_ADiGatorJac.robotArmObj_ADiGatorJac.Gator1Data;
% ADiGator Start Derivative Computations
%User Line: % Computes the objective function of the problem
cada1f1 = length(z.f);
tf.dz0 = z.dz0(1448);
tf.f = z.f(cada1f1);
%User Line: tf = z(end);
%User Line: % Cost function
J.dz0 = tf.dz0; J.f = tf.f;
%User Line: J   = tf;
obj.dz0 = J.dz0; obj.f = J.f;
%User Line: obj = J;
obj.dz0_size = 1448;
obj.dz0_location = Gator1Data.Index1;
end


function ADiGator_LoadData()
global ADiGator_robotArmObj_ADiGatorJac
ADiGator_robotArmObj_ADiGatorJac = load('robotArmObj_ADiGatorJac.mat');
return
end