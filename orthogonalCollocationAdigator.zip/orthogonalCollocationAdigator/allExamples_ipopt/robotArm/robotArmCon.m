function constraints = robotArmCon(Z)
% computes the constraints

output      = robotArmFun(Z);
constraints = output;

end

