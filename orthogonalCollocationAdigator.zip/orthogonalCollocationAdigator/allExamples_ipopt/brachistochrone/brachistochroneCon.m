function constraints = brachistochroneCon(Z)
% computes the constraints

output      = brachistochroneFun(Z);
constraints = output;

end

