function jacpat = brachistochroneJacPat(S_jac)
% computes the jacobian structure

jacpat = S_jac;

end

