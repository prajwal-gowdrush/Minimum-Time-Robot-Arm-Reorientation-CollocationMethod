function jac = brachistochroneJac(Z)
% computes the jacobian

[jac,~] = brachistochroneFun_Jac(Z);

end

