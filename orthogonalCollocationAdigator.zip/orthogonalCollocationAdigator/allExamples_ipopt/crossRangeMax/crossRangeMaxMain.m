%----------------------------------------------------------------------------------%
%                    Cross Range Maximization Problem                              %
%----------------------------------------------------------------------------------%
% Solve the following optimal control problem:                                     %
% Minimize -phi(t_f)                                                               %
% subject to the differential equation constraints                                 %
%       dr/dt = v*sin(gamma)                                                       %
% d(theta)/dt = v*cos(gamma)*sin(psi)/(r*cos(phi))                                 %
%   d(phi)/dt = v*cos(gamma)*cos(psi)/r                                            %
%       dv/dt = -Drag/m - g*sin(gamma)                                             %
% d(gamma)/dt = Lift*cos(sigma)/(m*v) - (g/v-v/r)*cos(gamma)                       %
%   d(psi)/dt = Lift*sin(sigma)/(m*v*cos(gamma)) + v*cos(gamma)*sin(psi)*tan(phi)/r%
%----------------------------------------------------------------------------------%
% Some definitions of the terms appearing in the dynamics                          % 
%  CD = CD0 + CD1*alpha +CD2*alpha^2                                               %
%  CL = CL0 + CL1*alpha                                                            %
%   h = r-Re
%   Drag = rho0*exp(-h/H)*v^2*S*CD/2                                               %
%   Lift = rho0*exp(-h/H)*v^2*S*CL/2                                               %
%   g = mu/r^2                                                                     %

%-----------------------------------------------------------------%
% BEGIN: DO NOT ALTER THE FOLLOWING LINES OF CODE!!!              %
%-----------------------------------------------------------------%
global Re S CD0 CD1 CD2 CL0 CL1 H rho0 mu m psStuff nstates ncontrols
global iGfun jGvar
%-----------------------------------------------------------------%
% END:   DO NOT ALTER THE FOLLOWING LINES OF CODE!!!              %
%-----------------------------------------------------------------%
%-----------------------------------------------------------------%
%             Define the constants for the problem                %
%-----------------------------------------------------------------%
Re=6.37120392e6;
S=249.9091776;
CD0=0.0785; CD1=(-0.3529); CD2=2.04;
CL0=(-0.207); CL1=1.6756;
H=7254.24;
rho0=1.225571 ;
mu=3.986032e14;
m=92079.253;

%-----------------------------------------------------------------%
%  Define the sizes of quantities in the optimal control problem  %
%-----------------------------------------------------------------%
nstates = 6;
ncontrols = 2;

%-----------------------------------------------------------------%
%  Define bounds on the variables in the optimal control problem  %
%-----------------------------------------------------------------%
r0=79248+Re;  theta0=0;  phi0=0; v0=7802.88;  gamma0=(-1*pi/180);   psi0=90*pi/180;
rf=24384+Re;  vf=762; gammaf=(-5*pi/180); 
% rmin=Re+(rf-Re)*0.95;  rmax=Re+(r0-Re)*1.1;
% thetamin=(0);      thetamax=pi;
% phimin=(0);        phimax=2*pi;
% vmin= 500;                vmax=8000; 
% gammamin=-15*pi/180;   gammamax= -gammamin;
% psimin= -pi;        psimax= -psimin;
% alphamin=(-20*pi/180);      alphamax=20*pi/180;
% sigmamin= -80*pi/180;        sigmamax= +80*pi/180;
% t0min = 0;             t0max = 0;
% tfmin = 0;             tfmax = 3000;

rmin=Re+(rf-Re)*0.95;  rmax=Re+(r0-Re)*1.1;
thetamin=(0);          thetamax=pi/2;
phimin=(0);            phimax=pi/2;
vmin= 500;              vmax=8000; 
gammamin=-15*pi/180;   gammamax= -gammamin;
psimin= 0;             psimax= 95*pi/180;
alphamin=(15*pi/180);  alphamax=20*pi/180;
sigmamin=-80*pi/180;  sigmamax= 10*pi/180;
t0min = 0;             t0max = 0;
tfmin = 0;             tfmax = 3000;
%-----------------------------------------------------------------%
% In this section, we define the three type of discretizations    %
% that can be employed.  These three approaches are as follows:   %
%    (1) p-method  = global pseudospectral method                 %
%                  = single interval and the degree of the        %
%                    polynomial in the interval can be varied     %
%    (2) h-method  = fixed-degree polynomial in each interval     %
%                    and the number of intervals can be varied    %
%    (3) hp-method = can vary BOTH the degree of the polynomial   %
%                    in each interval and the number of intervals %
%                                                                 %
% For simplicity in this tutorial, we will allow for either a     %
% p-method or an h-method.  Regardless of which method is being   %
% employed, the user needs to specify the following parameters:   %
%    (a) N = Polynomial Degree                                    %
%    (b) meshPoints = Set of Monotonically Increasing Mesh Points %
%                     on the Interval $\tau\in[-1,+1]$.           %
%                                                                 %
% When using a p-method, the parameters N and meshPoints must be  %
% specified as follows:                                           %
%    (i)  meshPoints = [-1 1]                                     %
%    (ii) N = Choice of Polynomial Degree (e.g., N=10, N=20)      %
% When using an h-method, the parameters N and meshPoints must be %
% specified as follows:                                           %
%    (i)  meshPoints = $[\tau_1,\tau_2,\tau_3,\ldots,\tau_N]$     %
%                      where $\tau_1 = -1$, $\tau_N = 1$ and      %
%                      (\tau_2,\ldots,\tau_{N-1}) are             %
%                      monotonically increasing on the open       %
%                      interval $(-1,+1)$.                        %
%-----------------------------------------------------------------%
%      Compute Points, Weights, and Differentiation Matrix        %
%-----------------------------------------------------------------%
%-----------------------------------------------------------------%
% Choose Polynomial Degree and Number of Mesh Intervals           %
% numIntervals = 1 ===> p-method                                  %
% numIntervals > 1 ===> h-method                                  %
%-----------------------------------------------------------------%
N = 8;
numIntervals = 15;
%-----------------------------------------------------------------%
% DO NOT ALTER THE LINE OF CODE SHOWN BELOW!                      %
%-----------------------------------------------------------------%
meshPoints = linspace(-1,1,numIntervals+1).';  
polyDegrees = N*ones(numIntervals,1);
[tau,w,D] = lgrPS(meshPoints,polyDegrees);
psStuff.tau = tau; psStuff.w = w; psStuff.D = D; NLGR = length(w);
%-----------------------------------------------------------------%
% DO NOT ALTER THE LINES OF CODE SHOWN ABOVE!                     %
%-----------------------------------------------------------------%
%-----------------------------------------------------------------%
% Set the bounds on the variables in the NLP.                     %
%-----------------------------------------------------------------%
zrmin = rmin*ones(length(tau),1);
zrmax = rmax*ones(length(tau),1);
zrmin(1) = r0; zrmax(1) = r0;
zrmin(NLGR+1) = rf; zrmax(NLGR+1) = rf;

zthetamin = thetamin*ones(length(tau),1);
zthetamax = thetamax*ones(length(tau),1);
zthetamin(1) = theta0; zthetamax(1) = theta0;

zphimin = phimin*ones(length(tau),1);
zphimax = phimax*ones(length(tau),1);
zphimin(1) = phi0; zphimax(1) = phi0;

zvmin = vmin*ones(length(tau),1);
zvmax = vmax*ones(length(tau),1);
zvmin(1) = v0; zvmax(1) = v0;
zvmin(NLGR+1) = vf; zvmax(NLGR+1) = vf;

zgammamin = gammamin*ones(length(tau),1);
zgammamax = gammamax*ones(length(tau),1);
zgammamin(1) = gamma0; zgammamax(1) = gamma0;
zgammamin(NLGR+1) = gammaf; zgammamax(NLGR+1) = gammaf;

zpsimin = psimin*ones(length(tau),1);
zpsimax = psimax*ones(length(tau),1);
zpsimin(1) = psi0; zpsimax(1) = psi0;

zalphamin = alphamin*ones(length(tau)-1,1);
zalphamax = alphamax*ones(length(tau)-1,1);

zsigmamin = sigmamin*ones(length(tau)-1,1);
zsigmamax = sigmamax*ones(length(tau)-1,1);

zmin = [zrmin; zthetamin; zphimin; zvmin; zgammamin; zpsimin; zalphamin; zsigmamin; t0min; tfmin];
zmax = [zrmax; zthetamax; zphimax; zvmax; zgammamax; zpsimax; zalphamax; zsigmamax; t0max; tfmax];

%-----------------------------------------------------------------%
% Set the bounds on the constraints in the NLP.                   %
%-----------------------------------------------------------------%
defectMin = zeros(nstates*(length(tau)-1),1);
defectMax = zeros(nstates*(length(tau)-1),1);
pathMin = []; pathMax = [];
eventMin = []; eventMax = [];
Fmin = [defectMin; pathMin; eventMin];
Fmax = [defectMax; pathMax; eventMax];

%-----------------------------------------------------------------%
% Supply an initial guess for the NLP.                            %
%-----------------------------------------------------------------%
rguess = linspace(r0,rf,NLGR+1).';
thetaguess = linspace(theta0,pi/2,NLGR+1).';
phiguess = linspace(phi0,pi/2,NLGR+1).';
vguess = linspace(v0,vf,NLGR+1).';
gammaguess = linspace(gamma0,gammaf,NLGR+1).';
psiguess = linspace(psi0,95*pi/180,NLGR+1).';
alphaguess=linspace(0,0,NLGR).';
sigmaguess=linspace(0,0,NLGR).';
t0guess = 0;
tfguess = 3000;
z0 = [rguess; thetaguess; phiguess; vguess; gammaguess; psiguess; alphaguess; sigmaguess; t0guess; tfguess];

%-----------------------------------------------------------------%
% Generate derivatives and sparsity pattern using Adigator        %
%-----------------------------------------------------------------%
% - Constraint Function Derivatives
xsize  = size(z0);
x      = adigatorCreateDerivInput(xsize,'z0');
output = adigatorGenJacFile('crossRangeMaxFun',{x});
S_jac  = output.JacobianStructure;
[iGfun,jGvar] = find(S_jac);

% - Objective Function Derivatives
xsize  = size(z0);
x      = adigatorCreateDerivInput(xsize,'z0');
output = adigatorGenJacFile('crossRangeMaxObj',{x});
grd_structure = output.JacobianStructure;

%-----------------------------------------------------------------%
% Set IPOPT callback functions
%-----------------------------------------------------------------%
funcs.objective   = @(Z)crossRangeMaxObj(Z);
funcs.gradient    = @(Z)crossRangeMaxGrd(Z);
funcs.constraints = @(Z)crossRangeMaxCon(Z);
funcs.jacobian    = @(Z)crossRangeMaxJac(Z);
funcs.jacobianstructure = @()crossRangeMaxJacPat(S_jac);
options.ipopt.hessian_approximation = 'limited-memory';

%-----------------------------------------------------------------%
% Set IPOPT Options %
%-----------------------------------------------------------------%
options.ipopt.tol = 1e-5;
options.ipopt.linear_solver = 'ma57';
options.ipopt.max_iter = 2000;
options.ipopt.mu_strategy = 'adaptive';
options.ipopt.ma57_automatic_scaling = 'yes';
options.ipopt.print_user_options = 'yes';
options.ipopt.output_file = ['crossRangeMax','IPOPTinfo.txt']; % print output file
options.ipopt.print_level = 5; % set print level default

options.lb = zmin; % Lower bound on the variables.
options.ub = zmax; % Upper bound on the variables.
options.cl = Fmin; % Lower bounds on the constraint functions.
options.cu = Fmax; % Upper bounds on the constraint functions.

%-----------------------------------------------------------------%
% Call IPOPT
%-----------------------------------------------------------------%
[z, info] = ipopt(z0,funcs,options);

%-----------------------------------------------------------------%
% extract lagrange multipliers from ipopt output, info
%-----------------------------------------------------------------%
Fmul = info.lambda;

%-----------------------------------------------------------------%
% Extract the state and control from the decision vector z.       %
% Remember that the state is approximated at the LGR points       %
% plus the final point, while the control is only approximated    %
% at only the LGR points.                                         %
%-----------------------------------------------------------------%
r = z(1:NLGR+1);
theta = z((NLGR+1)+1:2*(NLGR+1));
phi = z(2*(NLGR+1)+1:3*(NLGR+1));
v = z(3*(NLGR+1)+1:4*(NLGR+1));
gamma = z(4*(NLGR+1)+1:5*(NLGR+1));
psi = z(5*(NLGR+1)+1:6*(NLGR+1));
alpha = z(6*(NLGR+1)+1:6*(NLGR+1)+NLGR);
sigma = z(6*(NLGR+1)+NLGR+1:6*(NLGR+1)+2*NLGR);
t0 = z(end-1);
tf = z(end);
t = (tf-t0)*(tau+1)/2+t0;
tLGR = t(1:end-1);

%-----------------------------------------------------------------%
% Extract the Lagrange multipliers corresponding                  %
% the defect constraints.                                         %
%-----------------------------------------------------------------%
multipliersDefects = Fmul(1:nstates*NLGR);
multipliersDefects = reshape(multipliersDefects,NLGR,nstates);
%-----------------------------------------------------------------%
% Compute the costates at the LGR points via transformation       %
%-----------------------------------------------------------------%
costateLGR = inv(diag(w))*multipliersDefects;
%-----------------------------------------------------------------%
% Compute the costate at the tau=+1 via transformation            %
%-----------------------------------------------------------------%
costateF = D(:,end).'*multipliersDefects;
%-----------------------------------------------------------------%
% Now assemble the costates into a single matrix                  %
%-----------------------------------------------------------------%
costate = [costateLGR; costateF];
lamr = costate(:,1); lamtheta = costate(:,2); lamphi = costate(:,3);
lamv = costate(:,4); lamgamma = costate(:,5); lampsi = costate(:,6);

%Evaluating the Hamiltonian to estimate the closeness of the obtained solution to the true optimal solution%
rLGR=r(1:(end-1)); thetaLGR=theta(1:(end-1)); phiLGR=phi(1:(end-1));
vLGR=v(1:(end-1)); gammaLGR=gamma(1:(end-1)); psiLGR=psi(1:(end-1));

lamrLGR=lamr(1:(end-1)); lamthetaLGR=lamtheta(1:(end-1)); lamphiLGR=lamphi(1:(end-1));
lamvLGR=lamv(1:(end-1)); lamgammaLGR=lamgamma(1:(end-1)); lampsiLGR=lampsi(1:(end-1));
CD = CD0 + CD1.*alpha +CD2.*alpha.^2;                                           
CL = CL0 + CL1.*alpha;                                                      
Drag = rho0.*exp(-(rLGR-Re)/H).*vLGR.^2.*S.*CD./2;
Lift = rho0.*exp(-(rLGR-Re)/H).*vLGR.^2.*S.*CL./2;
g = mu./rLGR.^2;

rdot=vLGR.*sin(gammaLGR);
thetadot=vLGR.*cos(gammaLGR).*sin(psiLGR)./(rLGR.*cos(phiLGR));
phidot=vLGR.*cos(gammaLGR).*cos(psiLGR)./rLGR;
vdot=-Drag./m - g.*sin(gammaLGR);
gammadot=Lift.*cos(sigma)./(m.*vLGR) - (g./vLGR - vLGR./rLGR).*cos(gammaLGR);
psidot=Lift.*sin(sigma)./(m.*vLGR.*cos(gammaLGR)) + vLGR.*cos(gammaLGR).*sin(psiLGR).*tan(phiLGR)./rLGR;

Hamiltonian=lamrLGR.*rdot + lamthetaLGR.*thetadot + lamphiLGR.*phidot + lamvLGR.*vdot + lamgammaLGR.*gammadot + lampsiLGR.*psidot;

%-----------------------------------------------------------------%
% plot results
%-----------------------------------------------------------------%
close all;
lw=1;
figure;
% subplot(2,3,1);
plot(t,r,'-b+','LineWidth',lw);
 xlabel('Time');
 yl1=ylabel('$r$');
 set(yl1,'Interpreter','latex');
grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
leg1=legend('$r$');
set(leg1,'Interpreter','latex');
hold on;

figure;
% subplot(2,3,2);
plot(t,v,'-g*','LineWidth',lw);
 xlabel('Time');
 yl2=ylabel('$v$');
 set(yl2,'Interpreter','latex');
grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
leg2=legend('$v$');
set(leg2,'Interpreter','latex');
hold on;

figure;
% subplot(2,3,3);
plot(t,theta,'-ro','LineWidth',lw);
 xlabel('Time');
 yl3=ylabel('$\theta$');
set(yl3,'Interpreter','latex');
 grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
leg3=legend('$\theta$');
set(leg3,'Interpreter','latex');
hold on;

figure;
% subplot(2,3,4);
plot(t,phi,'-bs','LineWidth',lw);
 xlabel('Time');
 yl4=ylabel('$\phi$');
 set(yl4,'Interpreter','latex');
grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
leg4=legend('$\phi$');
set(leg4,'Interpreter','latex');
hold on;

figure;
% subplot(2,3,5);
plot(t,gamma,'-b*','LineWidth',lw);
 xlabel('Time');
yl5=ylabel('$\gamma$');
set(yl5,'Interpreter','latex');
grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
leg5=legend('$\gamma$');
set(leg5,'Interpreter','latex');
hold on;

figure;
% subplot(2,3,6);
plot(t,psi,'-y+','LineWidth',lw);
 xlabel('Time');
 yl6=ylabel('$\psi$');
 set(yl6,'Interpreter','latex');
grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
leg6=legend('$\psi$');
set(leg6,'Interpreter','latex');
hold on;

figure;
plot(tLGR,alpha,'-ro',tLGR,sigma,'-bs','LineWidth',lw);
 xlabel('Time');
 ylabel('Controls');
title('Optimal Control');
grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
leg4=legend('$\alpha$','$\sigma$');
set(leg4,'Interpreter','latex');
hold on;

figure;
plot(t,lamr,'-b+',t,lamtheta,'-ro',t,lamphi,'-bs',t,lamv,'-go',t,lamgamma,'-mo',t,lampsi,'-y+','LineWidth',lw);
 xlabel('Time');
 ylabel('Costates');
title('Optimal Costate Trajectory');
grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
leg5=legend('$\lambda_r$','$\lambda_{\theta}$','$\lambda_{\phi}$','$\lambda_{v}$','$\lambda_{\gamma}$','$\lambda_{\psi}$');
set(leg5,'Interpreter','latex');
hold on;

figure;
plot(tLGR,Hamiltonian,'-bs','LineWidth',lw);
 xlabel('Time');
 yl9=ylabel('Hamiltonian');
grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
hold on;