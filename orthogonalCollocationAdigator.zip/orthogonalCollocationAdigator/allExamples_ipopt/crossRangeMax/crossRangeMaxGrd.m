function grd = crossRangeMaxGrd(Z)
% computes the gradient

output = crossRangeMaxObj_Jac(Z);
grd    = output;

end