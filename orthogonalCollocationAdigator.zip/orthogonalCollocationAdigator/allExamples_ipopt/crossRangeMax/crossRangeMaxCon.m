function constraints = crossRangeMaxCon(Z)
% computes the constraints

output      = crossRangeMaxFun(Z);
constraints = output;

end