function jac = crossRangeMaxJac(Z)
% computes the jacobian

[jac,~] = crossRangeMaxFun_Jac(Z);

end