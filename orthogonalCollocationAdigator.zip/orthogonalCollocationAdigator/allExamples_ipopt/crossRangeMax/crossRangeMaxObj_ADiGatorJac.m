% This code was generated using ADiGator version 1.4
% �2010-2014 Matthew J. Weinstein and Anil V. Rao
% ADiGator may be obtained at https://sourceforge.net/projects/adigator/ 
% Contact: mweinstein@ufl.edu
% Bugs/suggestions may be reported to the sourceforge forums
%                    DISCLAIMER
% ADiGator is a general-purpose software distributed under the GNU General
% Public License version 3.0. While the software is distributed with the
% hope that it will be useful, both the software and generated code are
% provided 'AS IS' with NO WARRANTIES OF ANY KIND and no merchantability
% or fitness for any purpose or application.

function obj = crossRangeMaxObj_ADiGatorJac(z)
global ADiGator_crossRangeMaxObj_ADiGatorJac
if isempty(ADiGator_crossRangeMaxObj_ADiGatorJac); ADiGator_LoadData(); end
Gator1Data = ADiGator_crossRangeMaxObj_ADiGatorJac.crossRangeMaxObj_ADiGatorJac.Gator1Data;
% ADiGator Start Derivative Computations
%User Line: % Computes the objective function of the problem
%User Line: %      DO NOT FOR ANY REASON ALTER THE LINE OF CODE BELOW!        %
global psStuff nstates 
%User Line: global
%User Line: %      DO NOT FOR ANY REASON ALTER THE LINE OF CODE ABOVE!        %
%User Line: %-----------------------------------------------------------------%
%User Line: %-----------------------------------------------------------------%
%User Line: %   - Legendre-Gauss-Radau points (psStuff.tau)                   %
%User Line: %-----------------------------------------------------------------%
tau = psStuff.tau;
%User Line: tau = psStuff.tau;
%User Line: %-----------------------------------------------------------------%
%User Line: % Extract the state vector from the NLP decision vector           %
%User Line: %-----------------------------------------------------------------%
cada1f1 = length(tau);
N.f = cada1f1 - 1;
%User Line: N = length(tau)-1;
cada1f1 = N.f + 1;
cada1f2 = nstates*cada1f1;
stateIndices.f = 1:cada1f2;
%User Line: stateIndices = 1:nstates*(N+1);
stateVector.dz0 = z.dz0(Gator1Data.Index1);
stateVector.f = z.f(stateIndices.f);
%User Line: stateVector = z(stateIndices);
%User Line: %---------------------------------------------------------------------------------------%
%User Line: % Reshape the state part of the NLP decision vector to a matrix of size(N+1) by nstates%
%User Line: %---------------------------------------------------------------------------------------%
cada1f1 = N.f + 1;
statePlusEnd.dz0 = stateVector.dz0;
statePlusEnd.f = reshape(stateVector.f,cada1f1,nstates);
%User Line: statePlusEnd   = reshape(stateVector,N+1,nstates);
%User Line: % Cost function
cada1f1 = N.f + 1;
cada1f2dz0 = statePlusEnd.dz0(363);
cada1f2 = statePlusEnd.f(cada1f1,3);
J.dz0 = -cada1f2dz0;
J.f = uminus(cada1f2);
%User Line: J   = -statePlusEnd(N+1,3);
obj.dz0 = J.dz0; obj.f = J.f;
%User Line: obj = J;
obj.dz0_size = 968;
obj.dz0_location = Gator1Data.Index2;
end


function ADiGator_LoadData()
global ADiGator_crossRangeMaxObj_ADiGatorJac
ADiGator_crossRangeMaxObj_ADiGatorJac = load('crossRangeMaxObj_ADiGatorJac.mat');
return
end