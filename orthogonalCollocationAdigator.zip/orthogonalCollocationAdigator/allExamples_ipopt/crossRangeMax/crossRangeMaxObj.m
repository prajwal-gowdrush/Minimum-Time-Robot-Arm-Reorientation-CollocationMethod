function obj = crossRangeMaxObj(z)
% Computes the objective function of the problem
%      DO NOT FOR ANY REASON ALTER THE LINE OF CODE BELOW!        %
global  psStuff nstates 
%      DO NOT FOR ANY REASON ALTER THE LINE OF CODE ABOVE!        %
%-----------------------------------------------------------------%

%-----------------------------------------------------------------%
%   - Legendre-Gauss-Radau points (psStuff.tau)                   %
%-----------------------------------------------------------------%
 tau = psStuff.tau;
%-----------------------------------------------------------------%
% Extract the state vector from the NLP decision vector           %
%-----------------------------------------------------------------%
N = length(tau)-1;
stateIndices = 1:nstates*(N+1);
stateVector = z(stateIndices);

%---------------------------------------------------------------------------------------%
% Reshape the state part of the NLP decision vector to a matrix of size(N+1) by nstates%
%---------------------------------------------------------------------------------------%
statePlusEnd   = reshape(stateVector,N+1,nstates);

% Cost function
J   = -statePlusEnd(N+1,3);
obj = J;

end