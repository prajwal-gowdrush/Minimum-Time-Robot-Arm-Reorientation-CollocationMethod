% This code was generated using ADiGator version 1.4
% �2010-2014 Matthew J. Weinstein and Anil V. Rao
% ADiGator may be obtained at https://sourceforge.net/projects/adigator/ 
% Contact: mweinstein@ufl.edu
% Bugs/suggestions may be reported to the sourceforge forums
%                    DISCLAIMER
% ADiGator is a general-purpose software distributed under the GNU General
% Public License version 3.0. While the software is distributed with the
% hope that it will be useful, both the software and generated code are
% provided 'AS IS' with NO WARRANTIES OF ANY KIND and no merchantability
% or fitness for any purpose or application.

function C = crossRangeMaxFun_ADiGatorJac(z)
global ADiGator_crossRangeMaxFun_ADiGatorJac
if isempty(ADiGator_crossRangeMaxFun_ADiGatorJac); ADiGator_LoadData(); end
Gator1Data = ADiGator_crossRangeMaxFun_ADiGatorJac.crossRangeMaxFun_ADiGatorJac.Gator1Data;
% ADiGator Start Derivative Computations
%User Line: %-----------------------------------------------------------------%
%User Line: % Constraint functions for the cross-range maximisation problem%
%User Line: %This function is designed to be used with the NLP solver SNOPT/IPOPT.                                                   %
%User Line: %-----------------------------------------------------------------%
%User Line: %      DO NOT FOR ANY REASON ALTER THE LINE OF CODE BELOW!        %
global Re S CD0 CD1 CD2 CL0 CL1 H rho0 mu m psStuff nstates ncontrols 
%User Line: global
%User Line: %      DO NOT FOR ANY REASON ALTER THE LINE OF CODE ABOVE!        %
%User Line: %-----------------------------------------------------------------%
%User Line: %-----------------------------------------------------------------%
%User Line: % Radau pseudospectral method quantities required:                %
%User Line: %   - Differentiation matrix (psStuff.D)                          %
%User Line: %   - Legendre-Gauss-Radau weights (psStuff.w)                    %
%User Line: %   - Legendre-Gauss-Radau points (psStuff.tau)                   %
%User Line: %-----------------------------------------------------------------%
D = psStuff.D;
%User Line: D = psStuff.D;
tau = psStuff.tau;
%User Line: tau = psStuff.tau;
w = psStuff.w;
%User Line: w = psStuff.w;
%User Line: %-----------------------------------------------------------------%
%User Line: % Decompose the NLP decision vector into pieces containing        %
%User Line: %    - the state                                                  %
%User Line: %    - the control                                                %
%User Line: %    - the initial time                                           %
%User Line: %    - the final time                                             %
%User Line: %-----------------------------------------------------------------%
cada1f1 = length(tau);
N.f = cada1f1 - 1;
%User Line: N = length(tau)-1;
cada1f1 = N.f + 1;
cada1f2 = nstates*cada1f1;
stateIndices.f = 1:cada1f2;
%User Line: stateIndices = 1:nstates*(N+1);
cada1f1 = N.f + 1;
cada1f2 = nstates*cada1f1;
cada1f3 = cada1f2 + 1;
cada1f4 = N.f + 1;
cada1f5 = nstates*cada1f4;
cada1f6 = ncontrols*N.f;
cada1f7 = cada1f5 + cada1f6;
controlIndices.f = cada1f3:cada1f7;
%User Line: controlIndices = (nstates*(N+1)+1):(nstates*(N+1)+ncontrols*N);
cada1f1 = length(controlIndices.f);
cada1f2 = controlIndices.f(cada1f1);
t0Index.f = cada1f2 + 1;
%User Line: t0Index = controlIndices(end)+1;
tfIndex.f = t0Index.f + 1;
%User Line: tfIndex = t0Index+1;
stateVector.dz0 = z.dz0(Gator1Data.Index1);
stateVector.f = z.f(stateIndices.f);
%User Line: stateVector = z(stateIndices);
controlVector.dz0 = z.dz0(Gator1Data.Index2);
controlVector.f = z.f(controlIndices.f);
%User Line: controlVector = z(controlIndices);
t0.dz0 = z.dz0(967);
t0.f = z.f(t0Index.f);
%User Line: t0 = z(t0Index);
tf.dz0 = z.dz0(968);
tf.f = z.f(tfIndex.f);
%User Line: tf = z(tfIndex);
%User Line: %-----------------------------------------------------------------%
%User Line: % Reshape the state and control parts of the NLP decision vector  %
%User Line: % to matrices of sizes (N+1) by nstates and (N+1) by ncontrols,   %
%User Line: % respectively.  The state is approximated at the N LGR points    %
%User Line: % plus the final point.  Thus, each column of the state vector is %
%User Line: % length N+1.  The LEFT-HAND SIDE of the defect constraints, D*X, %
%User Line: % uses the state at all of the points (N LGR points plus final    %
%User Line: % point).  The RIGHT-HAND SIDE of the defect constraints,         %
%User Line: % (tf-t0)F/2, uses the state and control at only the LGR points.  %
%User Line: % Thus, it is necessary to extract the state approximations at    %
%User Line: % only the N LGR points.  Finally, in the Radau pseudospectral    %
%User Line: % method, the control is approximated at only the N LGR points.   %
%User Line: %-----------------------------------------------------------------%
cada1f1 = N.f + 1;
statePlusEnd.dz0 = stateVector.dz0;
statePlusEnd.f = reshape(stateVector.f,cada1f1,nstates);
%User Line: statePlusEnd   = reshape(stateVector,N+1,nstates);
control.dz0 = controlVector.dz0;
control.f = reshape(controlVector.f,N.f,ncontrols);
%User Line: control = reshape(controlVector,N,ncontrols);
cada1f1 = size(statePlusEnd.f,1);
cada1f2 = cada1f1 - 1;
cada1f3 = 1:cada1f2;
stateLGR.dz0 = statePlusEnd.dz0(Gator1Data.Index3);
stateLGR.f = statePlusEnd.f(cada1f3,:);
%User Line: stateLGR = statePlusEnd(1:end-1,:);
%User Line: %-----------------------------------------------------------------%
%User Line: % Identify the components of the state column-wise from stateLGR. %
%User Line: %-----------------------------------------------------------------%
r.dz0 = stateLGR.dz0(Gator1Data.Index4);
r.f = stateLGR.f(:,1);
%User Line: r = stateLGR(:,1);
theta.dz0 = stateLGR.dz0(Gator1Data.Index5);
theta.f = stateLGR.f(:,2);
%User Line: theta = stateLGR(:,2);
phi.dz0 = stateLGR.dz0(Gator1Data.Index6);
phi.f = stateLGR.f(:,3);
%User Line: phi = stateLGR(:,3);
v.dz0 = stateLGR.dz0(Gator1Data.Index7);
v.f = stateLGR.f(:,4);
%User Line: v = stateLGR(:,4);
gamma.dz0 = stateLGR.dz0(Gator1Data.Index8);
gamma.f = stateLGR.f(:,5);
%User Line: gamma= stateLGR(:,5);
psi.dz0 = stateLGR.dz0(Gator1Data.Index9);
psi.f = stateLGR.f(:,6);
%User Line: psi= stateLGR(:,6);
alpha.dz0 = control.dz0(Gator1Data.Index10);
alpha.f = control.f(:,1);
%User Line: alpha = control(:,1);
sigma.dz0 = control.dz0(Gator1Data.Index11);
sigma.f = control.f(:,2);
%User Line: sigma = control(:,2);
%User Line: %-----------------------------------------------------------------%
%User Line: % Compute the right-hand side of the differential equations at    %
%User Line: % the N LGR points.  Each component of the right-hand side is     %
%User Line: % stored as a column vector of length N, that is each column has  %
%User Line: % the form                                                        %
%User Line: %                   [ f_i(x_1,u_1,t_1) ]                          %
%User Line: %                   [ f_i(x_2,u_2,t_2) ]                          %
%User Line: %                           .                                     %
%User Line: %                           .                                     %
%User Line: %                           .                                     %
%User Line: %                   [ f_i(x_N,u_N,t_N) ]                          %
%User Line: % where "i" is the right-hand side of the ith component of the    %
%User Line: % vector field f.  It is noted that in MATLAB the calculation of %
%User Line: % the right-hand side is vectorized.                              %
%User Line: %-----------------------------------------------------------------%
%User Line: % Computing some terms appearing in the RHS of the constraints %
cada1f1dz0 = CD1.*alpha.dz0;
cada1f1 = CD1*alpha.f;
cada1f2dz0 = cada1f1dz0;
cada1f2 = CD0 + cada1f1;
cada1f3dz0 = 2.*alpha.f(:).^(2-1).*alpha.dz0;
cada1f3 = alpha.f.^2;
cada1f4dz0 = CD2.*cada1f3dz0;
cada1f4 = CD2*cada1f3;
cada1td1 = cada1f2dz0;
cada1td1 = cada1td1 + cada1f4dz0;
CD.dz0 = cada1td1;
CD.f = cada1f2 + cada1f4;
%User Line: CD = CD0 + CD1.*alpha +CD2.*alpha.^2;
cada1f1dz0 = CL1.*alpha.dz0;
cada1f1 = CL1*alpha.f;
CL.dz0 = cada1f1dz0;
CL.f = CL0 + cada1f1;
%User Line: CL = CL0 + CL1.*alpha;
cada1f1dz0 = r.dz0;
cada1f1 = r.f - Re;
cada1f2dz0 = -cada1f1dz0;
cada1f2 = uminus(cada1f1);
cada1f3dz0 = cada1f2dz0./H;
cada1f3 = cada1f2/H;
cada1f4dz0 = exp(cada1f3(:)).*cada1f3dz0;
cada1f4 = exp(cada1f3);
cada1f5dz0 = rho0.*cada1f4dz0;
cada1f5 = rho0*cada1f4;
cada1f6dz0 = 2.*v.f(:).^(2-1).*v.dz0;
cada1f6 = v.f.^2;
cada1td1 = zeros(240,1);
cada1td1(Gator1Data.Index12) = cada1f6(:).*cada1f5dz0;
cada1td1(Gator1Data.Index13) = cada1td1(Gator1Data.Index13) + cada1f5(:).*cada1f6dz0;
cada1f7dz0 = cada1td1;
cada1f7 = cada1f5.*cada1f6;
cada1f8dz0 = S.*cada1f7dz0;
cada1f8 = cada1f7*S;
cada1tf1 = CD.f(Gator1Data.Index14);
cada1td1 = zeros(360,1);
cada1td1(Gator1Data.Index15) = cada1tf1(:).*cada1f8dz0;
cada1td1(Gator1Data.Index16) = cada1td1(Gator1Data.Index16) + cada1f8(:).*CD.dz0;
cada1f9dz0 = cada1td1;
cada1f9 = cada1f8.*CD.f;
Drag.dz0 = cada1f9dz0./2;
Drag.f = cada1f9/2;
%User Line: Drag = rho0.*exp(-(r-Re)/H).*v.^2.*S.*CD./2;
cada1f1dz0 = r.dz0;
cada1f1 = r.f - Re;
cada1f2dz0 = -cada1f1dz0;
cada1f2 = uminus(cada1f1);
cada1f3dz0 = cada1f2dz0./H;
cada1f3 = cada1f2/H;
cada1f4dz0 = exp(cada1f3(:)).*cada1f3dz0;
cada1f4 = exp(cada1f3);
cada1f5dz0 = rho0.*cada1f4dz0;
cada1f5 = rho0*cada1f4;
cada1f6dz0 = 2.*v.f(:).^(2-1).*v.dz0;
cada1f6 = v.f.^2;
cada1td1 = zeros(240,1);
cada1td1(Gator1Data.Index17) = cada1f6(:).*cada1f5dz0;
cada1td1(Gator1Data.Index18) = cada1td1(Gator1Data.Index18) + cada1f5(:).*cada1f6dz0;
cada1f7dz0 = cada1td1;
cada1f7 = cada1f5.*cada1f6;
cada1f8dz0 = S.*cada1f7dz0;
cada1f8 = cada1f7*S;
cada1tf1 = CL.f(Gator1Data.Index19);
cada1td1 = zeros(360,1);
cada1td1(Gator1Data.Index20) = cada1tf1(:).*cada1f8dz0;
cada1td1(Gator1Data.Index21) = cada1td1(Gator1Data.Index21) + cada1f8(:).*CL.dz0;
cada1f9dz0 = cada1td1;
cada1f9 = cada1f8.*CL.f;
Lift.dz0 = cada1f9dz0./2;
Lift.f = cada1f9/2;
%User Line: Lift = rho0.*exp(-(r-Re)/H).*v.^2.*S.*CL./2;
cada1f1dz0 = 2.*r.f(:).^(2-1).*r.dz0;
cada1f1 = r.f.^2;
g.dz0 = -mu./cada1f1(:).^2.*cada1f1dz0;
g.f = mu./cada1f1;
%User Line: g = mu./r.^2;
cada1f1dz0 = cos(gamma.f(:)).*gamma.dz0;
cada1f1 = sin(gamma.f);
cada1td1 = zeros(240,1);
cada1td1(Gator1Data.Index22) = cada1f1(:).*v.dz0;
cada1td1(Gator1Data.Index23) = cada1td1(Gator1Data.Index23) + v.f(:).*cada1f1dz0;
rdot.dz0 = cada1td1;
rdot.f = v.f.*cada1f1;
%User Line: rdot=v.*sin(gamma);
cada1f1dz0 = -sin(gamma.f(:)).*gamma.dz0;
cada1f1 = cos(gamma.f);
cada1td1 = zeros(240,1);
cada1td1(Gator1Data.Index24) = cada1f1(:).*v.dz0;
cada1td1(Gator1Data.Index25) = cada1td1(Gator1Data.Index25) + v.f(:).*cada1f1dz0;
cada1f2dz0 = cada1td1;
cada1f2 = v.f.*cada1f1;
cada1f3dz0 = cos(psi.f(:)).*psi.dz0;
cada1f3 = sin(psi.f);
cada1tf1 = cada1f3(Gator1Data.Index26);
cada1td1 = zeros(360,1);
cada1td1(Gator1Data.Index27) = cada1tf1(:).*cada1f2dz0;
cada1td1(Gator1Data.Index28) = cada1td1(Gator1Data.Index28) + cada1f2(:).*cada1f3dz0;
cada1f4dz0 = cada1td1;
cada1f4 = cada1f2.*cada1f3;
cada1f5dz0 = -sin(phi.f(:)).*phi.dz0;
cada1f5 = cos(phi.f);
cada1td1 = zeros(240,1);
cada1td1(Gator1Data.Index29) = cada1f5(:).*r.dz0;
cada1td1(Gator1Data.Index30) = cada1td1(Gator1Data.Index30) + r.f(:).*cada1f5dz0;
cada1f6dz0 = cada1td1;
cada1f6 = r.f.*cada1f5;
cada1tf1 = cada1f6(Gator1Data.Index31);
cada1td1 = zeros(600,1);
cada1td1(Gator1Data.Index32) = cada1f4dz0./cada1tf1(:);
cada1tf1 = cada1f4(Gator1Data.Index33);
cada1tf2 = cada1f6(Gator1Data.Index34);
cada1td1(Gator1Data.Index35) = cada1td1(Gator1Data.Index35) + -cada1tf1(:)./cada1tf2(:).^2.*cada1f6dz0;
thetadot.dz0 = cada1td1;
thetadot.f = cada1f4./cada1f6;
%User Line: thetadot=v.*cos(gamma).*sin(psi)./(r.*cos(phi));
cada1f1dz0 = -sin(gamma.f(:)).*gamma.dz0;
cada1f1 = cos(gamma.f);
cada1td1 = zeros(240,1);
cada1td1(Gator1Data.Index36) = cada1f1(:).*v.dz0;
cada1td1(Gator1Data.Index37) = cada1td1(Gator1Data.Index37) + v.f(:).*cada1f1dz0;
cada1f2dz0 = cada1td1;
cada1f2 = v.f.*cada1f1;
cada1f3dz0 = -sin(psi.f(:)).*psi.dz0;
cada1f3 = cos(psi.f);
cada1tf1 = cada1f3(Gator1Data.Index38);
cada1td1 = zeros(360,1);
cada1td1(Gator1Data.Index39) = cada1tf1(:).*cada1f2dz0;
cada1td1(Gator1Data.Index40) = cada1td1(Gator1Data.Index40) + cada1f2(:).*cada1f3dz0;
cada1f4dz0 = cada1td1;
cada1f4 = cada1f2.*cada1f3;
cada1tf1 = r.f(Gator1Data.Index41);
cada1td1 = zeros(480,1);
cada1td1(Gator1Data.Index42) = cada1f4dz0./cada1tf1(:);
cada1td1(Gator1Data.Index43) = cada1td1(Gator1Data.Index43) + -cada1f4(:)./r.f(:).^2.*r.dz0;
phidot.dz0 = cada1td1;
phidot.f = cada1f4./r.f;
%User Line: phidot=v.*cos(gamma).*cos(psi)./r;
cada1f1dz0 = -Drag.dz0;
cada1f1 = uminus(Drag.f);
cada1f2dz0 = cada1f1dz0./m;
cada1f2 = cada1f1/m;
cada1f3dz0 = cos(gamma.f(:)).*gamma.dz0;
cada1f3 = sin(gamma.f);
cada1td1 = zeros(240,1);
cada1td1(Gator1Data.Index44) = cada1f3(:).*g.dz0;
cada1td1(Gator1Data.Index45) = cada1td1(Gator1Data.Index45) + g.f(:).*cada1f3dz0;
cada1f4dz0 = cada1td1;
cada1f4 = g.f.*cada1f3;
cada1td1 = zeros(480,1);
cada1td1(Gator1Data.Index46) = cada1f2dz0;
cada1td1(Gator1Data.Index47) = cada1td1(Gator1Data.Index47) + -cada1f4dz0;
vdot.dz0 = cada1td1;
vdot.f = cada1f2 - cada1f4;
%User Line: vdot=-Drag./m - g.*sin(gamma);
cada1f1dz0 = -sin(sigma.f(:)).*sigma.dz0;
cada1f1 = cos(sigma.f);
cada1tf1 = cada1f1(Gator1Data.Index48);
cada1td1 = zeros(480,1);
cada1td1(Gator1Data.Index49) = cada1tf1(:).*Lift.dz0;
cada1td1(Gator1Data.Index50) = cada1td1(Gator1Data.Index50) + Lift.f(:).*cada1f1dz0;
cada1f2dz0 = cada1td1;
cada1f2 = Lift.f.*cada1f1;
cada1f3dz0 = m.*v.dz0;
cada1f3 = m*v.f;
cada1tf1 = cada1f3(Gator1Data.Index51);
cada1td1 = cada1f2dz0./cada1tf1(:);
cada1td1(Gator1Data.Index52) = cada1td1(Gator1Data.Index52) + -cada1f2(:)./cada1f3(:).^2.*cada1f3dz0;
cada1f4dz0 = cada1td1;
cada1f4 = cada1f2./cada1f3;
cada1td1 = zeros(240,1);
cada1td1(Gator1Data.Index53) = g.dz0./v.f(:);
cada1td1(Gator1Data.Index54) = cada1td1(Gator1Data.Index54) + -g.f(:)./v.f(:).^2.*v.dz0;
cada1f5dz0 = cada1td1;
cada1f5 = g.f./v.f;
cada1td1 = zeros(240,1);
cada1td1(Gator1Data.Index55) = v.dz0./r.f(:);
cada1td1(Gator1Data.Index56) = cada1td1(Gator1Data.Index56) + -v.f(:)./r.f(:).^2.*r.dz0;
cada1f6dz0 = cada1td1;
cada1f6 = v.f./r.f;
cada1td1 = cada1f5dz0;
cada1td1 = cada1td1 + -cada1f6dz0;
cada1f7dz0 = cada1td1;
cada1f7 = cada1f5 - cada1f6;
cada1f8dz0 = -sin(gamma.f(:)).*gamma.dz0;
cada1f8 = cos(gamma.f);
cada1tf1 = cada1f8(Gator1Data.Index57);
cada1td1 = zeros(360,1);
cada1td1(Gator1Data.Index58) = cada1tf1(:).*cada1f7dz0;
cada1td1(Gator1Data.Index59) = cada1td1(Gator1Data.Index59) + cada1f7(:).*cada1f8dz0;
cada1f9dz0 = cada1td1;
cada1f9 = cada1f7.*cada1f8;
cada1td1 = zeros(600,1);
cada1td1(Gator1Data.Index60) = cada1f4dz0;
cada1td1(Gator1Data.Index61) = cada1td1(Gator1Data.Index61) + -cada1f9dz0;
gammadot.dz0 = cada1td1;
gammadot.f = cada1f4 - cada1f9;
%User Line: gammadot=Lift.*cos(sigma)./(m.*v) - (g./v - v./r).*cos(gamma);
cada1f1dz0 = cos(sigma.f(:)).*sigma.dz0;
cada1f1 = sin(sigma.f);
cada1tf1 = cada1f1(Gator1Data.Index62);
cada1td1 = zeros(480,1);
cada1td1(Gator1Data.Index63) = cada1tf1(:).*Lift.dz0;
cada1td1(Gator1Data.Index64) = cada1td1(Gator1Data.Index64) + Lift.f(:).*cada1f1dz0;
cada1f2dz0 = cada1td1;
cada1f2 = Lift.f.*cada1f1;
cada1f3dz0 = m.*v.dz0;
cada1f3 = m*v.f;
cada1f4dz0 = -sin(gamma.f(:)).*gamma.dz0;
cada1f4 = cos(gamma.f);
cada1td1 = zeros(240,1);
cada1td1(Gator1Data.Index65) = cada1f4(:).*cada1f3dz0;
cada1td1(Gator1Data.Index66) = cada1td1(Gator1Data.Index66) + cada1f3(:).*cada1f4dz0;
cada1f5dz0 = cada1td1;
cada1f5 = cada1f3.*cada1f4;
cada1tf1 = cada1f5(Gator1Data.Index67);
cada1td1 = zeros(600,1);
cada1td1(Gator1Data.Index68) = cada1f2dz0./cada1tf1(:);
cada1tf1 = cada1f2(Gator1Data.Index69);
cada1tf2 = cada1f5(Gator1Data.Index70);
cada1td1(Gator1Data.Index71) = cada1td1(Gator1Data.Index71) + -cada1tf1(:)./cada1tf2(:).^2.*cada1f5dz0;
cada1f6dz0 = cada1td1;
cada1f6 = cada1f2./cada1f5;
cada1f7dz0 = -sin(gamma.f(:)).*gamma.dz0;
cada1f7 = cos(gamma.f);
cada1td1 = zeros(240,1);
cada1td1(Gator1Data.Index72) = cada1f7(:).*v.dz0;
cada1td1(Gator1Data.Index73) = cada1td1(Gator1Data.Index73) + v.f(:).*cada1f7dz0;
cada1f8dz0 = cada1td1;
cada1f8 = v.f.*cada1f7;
cada1f9dz0 = cos(psi.f(:)).*psi.dz0;
cada1f9 = sin(psi.f);
cada1tf1 = cada1f9(Gator1Data.Index74);
cada1td1 = zeros(360,1);
cada1td1(Gator1Data.Index75) = cada1tf1(:).*cada1f8dz0;
cada1td1(Gator1Data.Index76) = cada1td1(Gator1Data.Index76) + cada1f8(:).*cada1f9dz0;
cada1f10dz0 = cada1td1;
cada1f10 = cada1f8.*cada1f9;
cada1f11dz0 = sec(phi.f(:)).^2.*phi.dz0;
cada1f11 = tan(phi.f);
cada1tf1 = cada1f11(Gator1Data.Index77);
cada1td1 = zeros(480,1);
cada1td1(Gator1Data.Index78) = cada1tf1(:).*cada1f10dz0;
cada1td1(Gator1Data.Index79) = cada1td1(Gator1Data.Index79) + cada1f10(:).*cada1f11dz0;
cada1f12dz0 = cada1td1;
cada1f12 = cada1f10.*cada1f11;
cada1tf1 = r.f(Gator1Data.Index80);
cada1td1 = zeros(600,1);
cada1td1(Gator1Data.Index81) = cada1f12dz0./cada1tf1(:);
cada1td1(Gator1Data.Index82) = cada1td1(Gator1Data.Index82) + -cada1f12(:)./r.f(:).^2.*r.dz0;
cada1f13dz0 = cada1td1;
cada1f13 = cada1f12./r.f;
cada1td1 = zeros(840,1);
cada1td1(Gator1Data.Index83) = cada1f6dz0;
cada1td1(Gator1Data.Index84) = cada1td1(Gator1Data.Index84) + cada1f13dz0;
psidot.dz0 = cada1td1;
psidot.f = cada1f6 + cada1f13;
%User Line: psidot=Lift.*sin(sigma)./(m.*v.*cos(gamma)) + v.*cos(gamma).*sin(psi).*tan(phi)./r;
cada1td1 = zeros(3240,1);
cada1td1(Gator1Data.Index85) = rdot.dz0;
cada1td1(Gator1Data.Index86) = thetadot.dz0;
cada1td1(Gator1Data.Index87) = phidot.dz0;
cada1td1(Gator1Data.Index88) = vdot.dz0;
cada1td1(Gator1Data.Index89) = gammadot.dz0;
cada1td1(Gator1Data.Index90) = psidot.dz0;
diffeqRHS.dz0 = cada1td1;
diffeqRHS.f = [rdot.f thetadot.f phidot.f vdot.f gammadot.f psidot.f];
%User Line: diffeqRHS = [rdot, thetadot, phidot, vdot,  gammadot, psidot];
%User Line: %-----------------------------------------------------------------%
%User Line: % Compute the left-hand side of the defect constraints, recalling %
%User Line: % that the left-hand side is computed using the state at the LGR  %
%User Line: % points PLUS the final point.                                    %
%User Line: %-----------------------------------------------------------------%
cada1td1 = sparse(Gator1Data.Index91,Gator1Data.Index92,statePlusEnd.dz0,121,726);
cada1td1 = D*cada1td1;
cada1td1 = cada1td1(:);
diffeqLHS.dz0 = full(cada1td1(Gator1Data.Index93));
diffeqLHS.f = D*statePlusEnd.f;
%User Line: diffeqLHS = D*statePlusEnd;
%User Line: %-----------------------------------------------------------------%
%User Line: % Construct the defect constraints at the N LGR points.           %
%User Line: % Remember that the right-hand side needs to be scaled by the     %
%User Line: % factor (tf-t0)/2 because the rate of change of the state is     %
%User Line: % being taken with respect to $\tau\in[-1,+1]$.  Thus, we have    %
%User Line: % $dt/t\dau=(tf-t0)/2$.                                           %
%User Line: %-----------------------------------------------------------------%
cada1td1 = zeros(2,1);
cada1td1(2) = tf.dz0;
cada1td1(1) = cada1td1(1) + -t0.dz0;
cada1f1dz0 = cada1td1;
cada1f1 = tf.f - t0.f;
cada1tempdz0 = cada1f1dz0(Gator1Data.Index94);
cada1tf1 = diffeqRHS.f(Gator1Data.Index95);
cada1td1 = zeros(4680,1);
cada1td1(Gator1Data.Index96) = cada1tf1(:).*cada1tempdz0;
cada1td1(Gator1Data.Index97) = cada1td1(Gator1Data.Index97) + cada1f1.*diffeqRHS.dz0;
cada1f2dz0 = cada1td1;
cada1f2 = cada1f1*diffeqRHS.f;
cada1f3dz0 = cada1f2dz0./2;
cada1f3 = cada1f2/2;
cada1td1 = zeros(10800,1);
cada1td1(Gator1Data.Index98) = diffeqLHS.dz0;
cada1td1(Gator1Data.Index99) = cada1td1(Gator1Data.Index99) + -cada1f3dz0;
defects.dz0 = cada1td1;
defects.f = diffeqLHS.f - cada1f3;
%User Line: defects = diffeqLHS-(tf-t0)*diffeqRHS/2;
%User Line: %-----------------------------------------------------------------%
%User Line: % Reshape the defect contraints into a column vector.             %
%User Line: %-----------------------------------------------------------------%
cada1f1 = N.f*nstates;
defects.dz0 = defects.dz0;
defects.f = reshape(defects.f,cada1f1,1);
%User Line: defects = reshape(defects,N*nstates,1);
%User Line: %-----------------------------------------------------------------%
%User Line: % Construct the objective function plus constraint vector.        %
%User Line: %-----------------------------------------------------------------%
C.dz0 = defects.dz0; C.f = defects.f;
%User Line: C = defects;
C.dz0_size = [720,968];
C.dz0_location = Gator1Data.Index100;
end


function ADiGator_LoadData()
global ADiGator_crossRangeMaxFun_ADiGatorJac
ADiGator_crossRangeMaxFun_ADiGatorJac = load('crossRangeMaxFun_ADiGatorJac.mat');
return
end