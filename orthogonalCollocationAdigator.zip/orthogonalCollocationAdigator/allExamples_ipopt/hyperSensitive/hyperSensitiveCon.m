function constraints = hyperSensitiveCon(Z)
% computes the constraints by evaluating the problem function

output      = hyperSensitiveFun(Z);
constraints = output; 

end

