function jac = hyperSensitiveJac(Z)
% computes the jacobian

[jac,~] = hyperSensitiveFun_Jac(Z);

end

