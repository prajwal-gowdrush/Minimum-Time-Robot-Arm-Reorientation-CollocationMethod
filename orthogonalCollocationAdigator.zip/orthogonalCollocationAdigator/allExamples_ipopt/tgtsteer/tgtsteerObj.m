function obj = tgtsteerObj(z)
% Computes the objective function of the problem

tf = z(end);

% Cost function
J   = tf;
obj = J;

end

