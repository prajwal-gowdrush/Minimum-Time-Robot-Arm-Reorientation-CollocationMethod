function grd = tgtsteerGrd(Z)
% computes the gradient

output = tgtsteerObj_Jac(Z);
grd    = output;

end

