%-----------------------------------------------------------------%
%            Linear Tangent Steering Problem                      %
%-----------------------------------------------------------------%
% Solve the following optimal control problem:                    %
% Minimize t_f                                                    %
% subject to the differential equation constraints                %
% dx1/dt= x3                                                      %
% dx2/dt= x4                                                      %
% dx3/dt= a*cos(u)
% dx4/dt= a*sin(u)
%-----------------------------------------------------------------%
% BEGIN: DO NOT ALTER THE FOLLOWING LINES OF CODE!!!              %
%-----------------------------------------------------------------%
global a psStuff nstates ncontrols
global iGfun jGvar
%-----------------------------------------------------------------%
% END:   DO NOT ALTER THE FOLLOWING LINES OF CODE!!!              %
%-----------------------------------------------------------------%


%-----------------------------------------------------------------%
%             Define the constants for the problem                %
%-----------------------------------------------------------------%
a=100;

%-----------------------------------------------------------------%
%  Define the sizes of quantities in the optimal control problem  %
%-----------------------------------------------------------------%
nstates = 4;
ncontrols = 1;

%-----------------------------------------------------------------%
%  Define bounds on the variables in the optimal control problem  %
%-----------------------------------------------------------------%
x10=0;  x20=0; x30=0; x40=0;
x2f=5; x3f=45; x4f=0;
x1min = -20; x1max = 50;
x2min = -20; x2max = 20;
x3min = -20; x3max = 50;
x4min = -20; x4max = 20;
umin = -pi;  umax = pi;
t0min = 0; t0max = 0;
tfmin = 0; tfmax = 10;

%-----------------------------------------------------------------%
% In this section, we define the three type of discretizations    %
% that can be employed.  These three approaches are as follows:   %
%    (1) p-method  = global pseudospectral method                 %
%                  = single interval and the degree of the        %
%                    polynomial in the interval can be varied     %
%    (2) h-method  = fixed-degree polynomial in each interval     %
%                    and the number of intervals can be varied    %
%    (3) hp-method = can vary BOTH the degree of the polynomial   %
%                    in each interval and the number of intervals %
%                                                                 %
% For simplicity in this tutorial, we will allow for either a     %
% p-method or an h-method.  Regardless of which method is being   %
% employed, the user needs to specify the following parameters:   %
%    (a) N = Polynomial Degree                                    %
%    (b) meshPoints = Set of Monotonically Increasing Mesh Points %
%                     on the Interval $\tau\in[-1,+1]$.           %
%                                                                 %
% When using a p-method, the parameters N and meshPoints must be  %
% specified as follows:                                           %
%    (i)  meshPoints = [-1 1]                                     %
%    (ii) N = Choice of Polynomial Degree (e.g., N=10, N=20)      %
% When using an h-method, the parameters N and meshPoints must be %
% specified as follows:                                           %
%    (i)  meshPoints = $[\tau_1,\tau_2,\tau_3,\ldots,\tau_N]$     %
%                      where $\tau_1 = -1$, $\tau_N = 1$ and      %
%                      (\tau_2,\ldots,\tau_{N-1}) are             %
%                      monotonically increasing on the open       %
%                      interval $(-1,+1)$.                        %
%-----------------------------------------------------------------%
%      Compute Points, Weights, and Differentiation Matrix        %
%-----------------------------------------------------------------%
%-----------------------------------------------------------------%
% Choose Polynomial Degree and Number of Mesh Intervals           %
% numIntervals = 1 ===> p-method                                  %
% numIntervals > 1 ===> h-method                                  %
%-----------------------------------------------------------------%
N =8;
numIntervals = 20;
%-----------------------------------------------------------------%
% DO NOT ALTER THE LINE OF CODE SHOWN BELOW!                      %
%-----------------------------------------------------------------%
meshPoints = linspace(-1,1,numIntervals+1).';  
polyDegrees = N*ones(numIntervals,1);
[tau,w,D] = lgrPS(meshPoints,polyDegrees);
psStuff.tau = tau; psStuff.w = w; psStuff.D = D; NLGR = length(w);
%-----------------------------------------------------------------%
% DO NOT ALTER THE LINES OF CODE SHOWN ABOVE!                     %
%-----------------------------------------------------------------%

%-----------------------------------------------------------------%
% Set the bounds on the variables in the NLP.                     %
%-----------------------------------------------------------------%
zx1min = x1min*ones(length(tau),1);
zx1max = x1max*ones(length(tau),1);
zx1min(1) = x10;       zx1max(1) = x10;

zx2min = x2min*ones(length(tau),1);
zx2max = x2max*ones(length(tau),1);
zx2min(1) = x20;       zx2max(1) = x20;
zx2min(NLGR+1) = x2f;  zx2max(NLGR+1) = x2f;

zx3min = x3min*ones(length(tau),1);
zx3max = x3max*ones(length(tau),1);
zx3min(1) = x30;        zx3max(1) = x30;
zx3min(NLGR+1) = x3f;   zx3max(NLGR+1) = x3f;

zx4min = x4min*ones(length(tau),1);
zx4max = x4max*ones(length(tau),1);
zx4min(1) = x40;       zx4max(1) = x40;
zx4min(NLGR+1) = x4f;  zx4max(NLGR+1) = x4f;

zumin = umin*ones(length(tau)-1,1);
zumax = umax*ones(length(tau)-1,1);

zmin = [zx1min; zx2min; zx3min; zx4min; zumin; t0min; tfmin];
zmax = [zx1max; zx2max; zx3max; zx4max; zumax; t0max; tfmax];

%-----------------------------------------------------------------%
% Set the bounds on the constraints in the NLP.                   %
%-----------------------------------------------------------------%
defectMin = zeros(nstates*(length(tau)-1),1);
defectMax = zeros(nstates*(length(tau)-1),1);
pathMin = []; pathMax = [];
eventMin = []; eventMax = [];
Fmin = [ defectMin; pathMin; eventMin];
Fmax = [ defectMax; pathMax; eventMax];

%-----------------------------------------------------------------%
% Supply an initial guess for the NLP.                            %
%-----------------------------------------------------------------%
x1guess = linspace(x10,x10,NLGR+1).';
x2guess = linspace(x20,x2f,NLGR+1).';
x3guess = linspace(x30,x3f,NLGR+1).';
x4guess = linspace(x40,x4f,NLGR+1).';
uguess = linspace(0,0,NLGR).';
t0guess = 0;
tfguess = 15;
z0 = [x1guess; x2guess; x3guess; x4guess; uguess; t0guess; tfguess];

%-----------------------------------------------------------------%
% Generate derivatives and sparsity pattern using Adigator        %
%-----------------------------------------------------------------%
% - Constraint Funtction Derivatives
xsize  = size(z0);
x      = adigatorCreateDerivInput(xsize,'z0');
output = adigatorGenJacFile('tgtsteerFun',{x});
S_jac  = output.JacobianStructure;
[iGfun,jGvar] = find(S_jac);

% - Objective Funtcion Derivatives
xsize  = size(z0);
x      = adigatorCreateDerivInput(xsize,'z0');
output = adigatorGenJacFile('tgtsteerObj',{x});
grd_structure = output.JacobianStructure;

%-----------------------------------------------------------------%
% Set IPOPT callback functions
%-----------------------------------------------------------------%
funcs.objective   = @(Z)tgtsteerObj(Z);
funcs.gradient    = @(Z)tgtsteerGrd(Z);
funcs.constraints = @(Z)tgtsteerCon(Z);
funcs.jacobian    = @(Z)tgtsteerJac(Z);
funcs.jacobianstructure = @()tgtsteerJacPat(S_jac);
options.ipopt.hessian_approximation = 'limited-memory';

%-----------------------------------------------------------------%
% Set IPOPT Options %
%-----------------------------------------------------------------%
options.ipopt.tol = 1e-5;
options.ipopt.linear_solver = 'ma57';
options.ipopt.max_iter = 2000;
options.ipopt.mu_strategy = 'adaptive';
options.ipopt.ma57_automatic_scaling = 'yes';
options.ipopt.print_user_options = 'yes';
options.ipopt.output_file = ['robotArm','IPOPTinfo.txt']; % print output file
options.ipopt.print_level = 5; % set print level default

options.lb = zmin; % Lower bound on the variables.
options.ub = zmax; % Upper bound on the variables.
options.cl = Fmin; % Lower bounds on the constraint functions.
options.cu = Fmax; % Upper bounds on the constraint functions.

%-----------------------------------------------------------------%
% Call IPOPT
%-----------------------------------------------------------------%
[z, info] = ipopt(z0,funcs,options);

%-----------------------------------------------------------------%
% extract lagrange multipliers from ipopt output, info
%-----------------------------------------------------------------%
Fmul = info.lambda;

%-----------------------------------------------------------------%
% Extract the state and control from the decision vector z.       %
% Remember that the state is approximated at the LGR points       %
% plus the final point, while the control is only approximated    %
% at only the LGR points.                                         %
%-----------------------------------------------------------------%
x1 = z(1:NLGR+1);
x2 = z(NLGR+2:2*(NLGR+1));
x3 = z(2*(NLGR+1)+1:3*(NLGR+1));
x4 = z(3*(NLGR+1)+1:4*(NLGR+1));
u = z(4*(NLGR+1)+1:4*(NLGR+1)+NLGR);
t0 = z(end-1);
tf = z(end);
t = (tf-t0)*(tau+1)/2+t0;
tLGR = t(1:end-1);

%-----------------------------------------------------------------%
% Extract the Lagrange multipliers corresponding                  %
% the defect constraints.                                         %
%-----------------------------------------------------------------%
multipliersDefects = Fmul(1:nstates*NLGR);
multipliersDefects = reshape(multipliersDefects,NLGR,nstates);
%-----------------------------------------------------------------%
% Compute the costates at the LGR points via transformation       %
%-----------------------------------------------------------------%
costateLGR = inv(diag(w))*multipliersDefects;
%-----------------------------------------------------------------%
% Compute the costate at the tau=+1 via transformation            %
%-----------------------------------------------------------------%
costateF = D(:,end).'*multipliersDefects;
%-----------------------------------------------------------------%
% Now assemble the costates into a single matrix                  %
%-----------------------------------------------------------------%
costate = [costateLGR; costateF];
lamx1 = costate(:,1); lamx2 = costate(:,2); lamx3 = costate(:,3); lamx4 = costate(:,4); 

%Evaluating the Hamiltonian to estimate the closeness of the obtained solution to the true optimal solution%
x1LGR=x1(1:(end-1)); x2LGR=x2(1:(end-1)); x3LGR=x3(1:(end-1)); x4LGR=x4(1:(end-1));
lamx1LGR=lamx1(1:(end-1)); lamx2LGR=lamx2(1:(end-1)); lamx3LGR=lamx3(1:(end-1)); lamx4LGR=lamx4(1:(end-1));

x1dot=x3LGR;
x2dot=x4LGR;
x3dot=a*cos(u);
x4dot=a*sin(u);
Hamiltonian=lamx1LGR.*x1dot + lamx2LGR.*x2dot + lamx3LGR.*x3dot + lamx4LGR.*x4dot;
%-----------------------------------------------------------------%
% plot results
%-----------------------------------------------------------------%
close all;
lw=1;
figure;
subplot(2,2,1);
plot(t,x1,'-bs','LineWidth',lw);
 xlabel('Time');
 yl1=ylabel('$x_1$');
 set(yl1,'Interpreter','latex');
grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
leg1=legend('$x_1$');
set(leg1,'Interpreter','latex');
hold on;

% figure;
subplot(2,2,2);
plot(t,x2,'-bs','LineWidth',lw);
 xlabel('Time');
 yl2=ylabel('$x_2$');
 set(yl2,'Interpreter','latex');
grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
leg2=legend('$x_2$');
set(leg2,'Interpreter','latex');
hold on;

% figure;
subplot(2,2,3);
plot(t,x3,'-bs','LineWidth',lw);
 xlabel('Time');
 yl3=ylabel('$x_3$');
set(yl3,'Interpreter','latex');
 grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
leg3=legend('$x_3$');
set(leg3,'Interpreter','latex');
hold on;

% figure;
subplot(2,2,4);
plot(t,x4,'-bs','LineWidth',lw);
 xlabel('Time');
 yl4=ylabel('$x_4$');
 set(yl4,'Interpreter','latex');
grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
leg4=legend('$x_4$');
set(leg4,'Interpreter','latex');
hold on;


figure;
plot(tLGR,u,'-bs','LineWidth',lw);
 xlabel('Time');
 yl7=ylabel('$u$');
 set(yl7,'Interpreter','latex');
grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
leg5=legend('$u_1$');
set(leg5,'Interpreter','latex');
hold on;

figure;
plot(tLGR,Hamiltonian,'-bs','LineWidth',lw);
 xlabel('Time');
 yl9=ylabel('Hamiltonian');
grid on;
ax = gca;
ax.GridLineStyle = ':';
ax.GridAlpha = 0.3;
ax.FontSize = 16;
ax.LineWidth = 1.4;
hold on;