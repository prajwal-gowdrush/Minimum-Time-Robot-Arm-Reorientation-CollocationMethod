function jacpat = tgtsteerJacPat(S_jac)
% computes the jacobian structure

jacpat = S_jac;

end
