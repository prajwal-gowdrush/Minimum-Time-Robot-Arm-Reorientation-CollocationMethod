function jac = tgtsteerJac(Z)
% computes the jacobian

[jac,~] = tgtsteerFun_Jac(Z);

end

