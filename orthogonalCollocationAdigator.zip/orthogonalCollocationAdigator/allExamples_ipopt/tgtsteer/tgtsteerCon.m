function constraints = tgtsteerCon(Z)
% computes the constraints

output      = tgtsteerFun(Z);
constraints = output;

end

