clc; clear;
syms x1 x2 x3 x4 lambda1 lambda2 lambda3 lambda4 a u real
L=0;
X=[x1;x2;x3;x4];
f=[x3; x4; a*cos(u); a*sin(u)];
Lambda=[lambda1; lambda2; lambda3; lambda4];
H=L+Lambda'*f;
dHdu=diff(H,u);
Lambdadot=-jacobian(H,X);