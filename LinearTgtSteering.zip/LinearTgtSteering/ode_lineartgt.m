%% ODE function used to get a solution to the state+costate differential equation system (LinearTgt)
function Pdot=ode_lineartgt(~,P)
a=100;
x3=P(3); x4=P(4);
lambda1=P(5); lambda2=P(6); lambda3=P(7); lambda4=P(8);

%Control as given by the optimality conditions:
u=atan2(-lambda4,-lambda3);

Pdot(1,1)= x3;
Pdot(2,1)= x4;
Pdot(3,1)= a*cos(u);
Pdot(4,1)= a*sin(u);
Pdot(5,1)= 0;
Pdot(6,1)= 0;
Pdot(7,1)= -lambda1;
Pdot(8,1)= -lambda2;
end