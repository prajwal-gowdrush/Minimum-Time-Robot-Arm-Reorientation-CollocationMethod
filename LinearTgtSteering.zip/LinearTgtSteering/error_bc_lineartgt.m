%% Function to find the error in boundary conditions:(LinearTgtSteering)
function errvec=error_bc_lineartgt(Guess,X0)
a=100;
tfguess=Guess(end);
lambda0=Guess(1:end-1);
P0=[X0;lambda0];
tspan=[0 tfguess];

%% Numerical Integration over tspan
options = odeset('AbsTol',1e-10,'RelTol',1e-10);
[~,P_Sol]=ode113(@ode_lineartgt,tspan,P0,options);
P_tf=P_Sol(end,:)';

% The states and costates appearing in the boundary conditions at the final time
x2=P_tf(2); x3=P_tf(3); x4=P_tf(4);
lambda1=P_tf(5); lambda2=P_tf(6); lambda3=P_tf(7); lambda4=P_tf(8);
%CONTROL
u=atan2(-lambda4,-lambda3);
H=lambda1*x3 + lambda2*x4 + a*lambda3*cos(u) + a*lambda4*sin(u);
%% Computing error in the final boundary conditions
%(given and the ones arising from Transversality conditions conditions)
%Final boundary conditions
lambda1f=0;
x2f=5;
x3f=45;
x4f=0;
Hf=-1;
%Error
errvec=[lambda1-lambda1f; x2-x2f; x3-x3f; x4-x4f; H-Hf];
end