%% MainScript Linear Tangent Steering Problem
clc; clear;

%Defining the constants in the problem
a=100;

%Initial State
X0=[0;0;0;0];

%Guess for the costates
guessedlambdas=[0;1;1;1];

%Guess for the final time
tfguess= 4;

%Overall Guess vector
Guess=[guessedlambdas;tfguess];

% Iterative scheme using fsolve to find the correct guess
[CorrectGuess,fval,exitflag,output]=fsolve(@(Guess)error_bc_lineartgt(Guess,X0),Guess);

% Getting the states, costates and controls as functions of time by integrating using the correct guess
tf_optimal=CorrectGuess(end);
lambda0=CorrectGuess(1:end-1);
tspan=[0 tf_optimal];
P0=[X0;lambda0];
options = odeset('AbsTol',1e-10,'RelTol',1e-10);
[time,P_Sol]=ode113(@ode_lineartgt,tspan,P0,options);
X1=P_Sol(:,1); X2=P_Sol(:,2); X3=P_Sol(:,3); X4=P_Sol(:,4); 
Lambda1=P_Sol(:,5); Lambda2=P_Sol(:,6); Lambda3=P_Sol(:,7); Lambda4=P_Sol(:,8);
U=atan2(-Lambda4,-Lambda3);

%% Plots
figure;
subplot(2,2,1); plot(time,X1,'r',time,X2,'b',time,X3,'k',time,X4,'m','LineWidth',1.5);
xlabel('Time'); ylabel('States'); title('Optimal State Trajectory'); grid on;
xlim([0 time(end)]); ax = gca; ax.GridLineStyle = ':'; ax.GridAlpha = 0.3; ax.FontSize = 16; ax.LineWidth = 1.4;
leg1=legend('$x_1$','$x_2$','$x_3$','$x_4$'); set(leg1,'Interpreter','latex'); hold on;

subplot(2,2,2); plot(time,Lambda1,'r',time,Lambda2,'b',time,Lambda3,'k',time,Lambda4,'m','LineWidth',1.5);
xlabel('Time'); ylabel('Costates'); title('Optimal Costate Trajectory'); grid on;
xlim([0 time(end)]); ax = gca; ax.GridLineStyle = ':'; ax.GridAlpha = 0.3; ax.FontSize = 16; ax.LineWidth = 1.4;
leg2=legend('$\lambda_1$','$\lambda_2$','$\lambda_3$','$\lambda_4$'); set(leg2,'Interpreter','latex');
hold on;

subplot(2,2,3); plot(time,U,'b','LineWidth',1.5);
xlabel('Time'); ylabel('Control'); title('Control as a function of time'); grid on;
xlim([0 time(end)]); ax = gca; ax.GridLineStyle = ':'; ax.GridAlpha = 0.3; ax.FontSize = 16; ax.LineWidth = 1.4;
leg3=legend('$u$'); set(leg3,'Interpreter','latex'); hold on;

subplot(2,2,4); plot(X1,X2,'b','LineWidth',1.5);
title('Path taken by the particle in the XY-plane');
grid on; ax.GridLineStyle = ':'; ax.GridAlpha = 0.3; ax.FontSize = 16; ax.LineWidth = 1.4;
hold on;